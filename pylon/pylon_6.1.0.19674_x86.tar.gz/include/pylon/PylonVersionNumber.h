// This file has been generated automatically using:
// "/home/jenkins/workspace/pylon-release_release_pylon_6_1@2/Build/FileTemplates/PylonVersionNumber.template.h"
// DO NOT EDIT!

#define PYLON_VERSION_MAJOR           6
#define PYLON_VERSION_MINOR           1
#define PYLON_VERSION_SUBMINOR        0
#define PYLON_VERSION_BUILD           18286
#define PYLON_VERSIONSTRING_MAJOR     "6"
#define PYLON_VERSIONSTRING_MINOR     "1"
#define PYLON_VERSIONSTRING_SUBMINOR  "0"
#define PYLON_VERSIONSTRING_BUILD     "18286"
#define PYLON_VERSIONSTRING_EXTENSION ""
