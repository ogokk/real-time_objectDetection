var indexSectionsWithContent =
{
  0: "bcepsu",
  1: "b",
  2: "b",
  3: "bcpu",
  4: "e",
  5: "b",
  6: "be",
  7: "ps"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros",
  7: "Pages"
};

