var searchData=
[
  ['pfunc_5fbcon_5fadapter_5fdiscovery_5fcallback',['PFUNC_BCON_ADAPTER_DISCOVERY_CALLBACK',['../_bcon_adapter_enumerator_8h.html#ab7f4b8873afb4b469903b013cabb9750',1,'BconAdapterEnumerator.h']]]
];
